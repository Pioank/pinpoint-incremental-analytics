import os
import boto3
import json
import pandas as pd
from boto3.dynamodb.conditions import Key, Attr

region = os.environ['AWS_REGION']
pinpointid=os.environ['PINPOINT_ID']
honworkbookid = os.environ['WORKBOOK_ID']
hontableid = os.environ['TABLE_ID']

clientpin = boto3.client('pinpoint')
clienthon = boto3.client('honeycode', region_name='us-west-2') #Do not change the region as this service is currently available only in us-west-2
dynamodbendpointurl = "https://dynamodb." + region + ".amazonaws.com"
dynamodb = boto3.resource('dynamodb', endpoint_url=dynamodbendpointurl)
table = dynamodb.Table('kinesis_pinpoint_timeseries')
tableb = dynamodb.Table('kinesis_pinpoint_aggregator')

#Update Pinpoint endpoint
def updateendpoint(endpointid, honevent, campaignflag):
    clientpin.update_endpoint(
    ApplicationId=pinpointid,
    EndpointId= endpointid,
    EndpointRequest={'User':{'UserAttributes': {
            honevent: [campaignflag]}
            }}
    )

#Checks if the list has any Users and if yes then it loops through it and updates the user attribute    
def functoupdate(df, honevent): 
    listtoupdate=df['endpointid'].tolist() 
    if not listtoupdate:
        print('No users meet the criteria - metric not greater')
    else: 
        for endpointid in listtoupdate:
            campaignflag='ready'
            updateendpoint(endpointid, honevent, campaignflag)
        print('Criteria met, users elidgible: ' + str(len(listtoupdate)))

#Query DynamoDB to obtain all event records for that period     
def dynamoquery(honevent, honstartdate, honenddate, attributename, attributevalue):
    print(honevent, honstartdate, honenddate)
    response = table.query(KeyConditionExpression=Key('eventname').eq(honevent) & Key('dateuserid').between(honstartdate, honenddate))
    response=response['Items']
    df=pd.DataFrame(list(response),columns = ['eventname','dateuserid','count','endpointid','metric','attributes']) #Convert dictionary into Dataframe
    
    # Checks to see if rule contains event attribute and if yes filters the DynamoDB query results accordingly
    if attributename != "na":
        atkey = str("'" + attributename + "': " + "'" + attributevalue + "'")
        print(atkey)
        df=df[df['attributes'].str.contains(atkey)]
    
    print(df)
    
    df[['date','userid','timestamp']] = df.dateuserid.str.split("#",expand=True,) #Split the concatenated date-userid-timestamp into 3 columns
    df = df.groupby(['userid'], as_index=False).agg({'count':'sum', 'metric': 'sum', 'endpointid': 'first'}) #Group and sum by userid but preserve at least one endpoint id for that user
    print(df)
    
    return df

#Def below is not being used
#Update Pinpoint endpoint when rules are NOT met
def updateendpointnotmet(endpointid, honevent):
    
    #Get endpoint data
    attributecheck = clientpin.get_endpoint(
    ApplicationId=pinpointid,
    EndpointId=endpointid)
    
    #Obtain all User attributes
    attributecheck=attributecheck["EndpointResponse"]["User"]["UserAttributes"] 
    
    #Check if User attribute for that rule exist and if not the create it with value "notready"
    if honevent in attributecheck.keys():
        checkatt = "attribute_exists"
    else:
        checkatt = "attribute_doesnt_exist"
        clientpin.update_endpoint(
        ApplicationId=pinpointid,
        EndpointId= endpointid,
        EndpointRequest={'User':{'UserAttributes': {
                honevent: ["notready"]}
                }}
        )
    
    print("User endpoint updated " + checkatt)
    
def honcquery(honkey):
    honrows = clienthon.query_table_rows(workbookId=honworkbookid, tableId=hontableid, filterFormula={"formula": f'=Filter(rules,"rules[RuleType]=%","{honkey}")'}, maxResults=99)
    honrows=str(honrows).replace("'", '"')
    honrows=json.loads(honrows)
    honrows=honrows['rows']
    return(honrows)

# Retrieves all HoneyCode rules for aggregator and then delete    
def deleterecords(honkey):
    honrows = honcquery(honkey)
    allevents = []
    for row in honrows: #Loop through the rows that contain rules about date
        processrow=str(row).replace("'", '"')
        processrow = json.loads(processrow)
        processrow = processrow['cells']

        counter = 0 
        for cell in processrow: #Extract the event value for each rule
            if counter == 1:
                honevent = str(cell['formattedValue'])
            elif counter == 2:
                attributename = str(cell['formattedValue'])
                print("Attribute name: " + attributename)
            elif counter == 3:
                attributevalue = str(cell['formattedValue'])
                print("Attribute value: " + attributevalue)
            counter = counter + 1
            
        keyevent = str(honevent) + str(attributename) + str(attributevalue)
        allevents.append(keyevent)
    
    aggregatordb(allevents)
    
    
# Queries all Aggregator DB rows for a specific event and deletes them    
def aggregatordb(allevents):
    records = tableb.scan()
    records = records['Items']
    
    for record in records:
        eventname = str(record['eventname'])
        useridtaskname = str(record['useridtaskname'])
        
        if eventname not in allevents:
            print("Deleting all records from Aggregator DB for event: " + eventname)
            tableb.delete_item(
                Key={
                    'useridtaskname': useridtaskname,
                })

    if 'LastEvaluatedKey' in records:
        
        while 'LastEvaluatedKey' in records:
            records = tableb.scan(FilterExpression=Attr('eventname').eq(eventname), ExclusiveStartKey=records['LastEvaluatedKey'])
            for record in records:
                eventname = str(record['eventname'])
                useridtaskname = str(record['useridtaskname'])
                
                if eventname not in allevents:
                    tableb.delete_item(
                        Key={
                            'useridtaskname': useridtaskname,
                        })
