import json
import pandas as pd
import boto3
from boto3.dynamodb.conditions import Key
from interaction_function import dynamoquery, honcquery, deleterecords
from business_logic import businesslogic
import os
region = os.environ['AWS_REGION']
dynamodbendpointurl = "https://dynamodb." + region + ".amazonaws.com"

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


dynamodb = boto3.resource('dynamodb', endpoint_url=dynamodbendpointurl)
table = dynamodb.Table('firehoseanalyticshistory')
clientpin = boto3.client('pinpoint')

def lambda_handler(event, context):

    honkey = 'date' #Set the key to value date so that all HoneyCode rules for date will be returned
    honrows = honcquery(honkey) #retrieves the HoneyCode rules
   
    honkei='aggregator'
    deleterecords(honkei)
    
    for row in honrows: #Loop through the rows that contain rules about date
        processrow=str(row).replace("'", '"')
        processrow = json.loads(processrow)
        processrow = processrow['cells']
        
        counter = 0 
        for cell in processrow: #Extract the values for each rule
            if counter == 2:
                attributename = str(cell['formattedValue'])
                print("Attribute name: " + attributename)
            elif counter == 3:
                attributevalue = str(cell['formattedValue'])
                print("Attribute value: " + attributevalue)
            elif counter == 4:
                honoperator = cell['formattedValue']
                print("Count operator: " + honoperator)
            elif counter == 5:
                hontargetvalue = int(cell['formattedValue'])
                print("Count target value: " + str(hontargetvalue))
            elif counter == 1:
                honevent = str(cell['formattedValue'])
                print("Event name: " + honevent)
            elif counter == 8:
                honreset = cell['formattedValue']
                print("Reset flag value: " + honreset)
            elif counter == 6:
                honoperatorval = cell['formattedValue']
                print("Metric sum value: " + honoperatorval)
            elif counter == 7:
                hontargetvaluesum = cell['formattedValue']
                print("Metric sum target value: " + str(hontargetvaluesum))
            elif counter == 9:
                honstartdate = cell['formattedValue']
                print("Start date: " + honstartdate)
            elif counter == 10:
                honenddate = cell['formattedValue']
                print("End date: " + honenddate)
            counter = counter + 1
      
        
        # Obtain all Users that meet the criteria for that rule
        #dynamoquery(honevent, honstartdate, honenddate)
        try:
            df=dynamoquery(honevent, honstartdate, honenddate, attributename, attributevalue) #Selects all users for an event where HoneyCode rule exists and it has taken place in the defined per
        except:
            print("No user - event records for this rule have been found")
        else:
            businesslogic(honoperator, hontargetvalue, honoperatorval, hontargetvaluesum, df, honevent,attributename,attributevalue)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Query completed')
    }