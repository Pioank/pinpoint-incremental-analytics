from interaction_function import updateendpoint, functoupdate

def businesslogic(honoperator, hontargetvalue, honoperatorval, hontargetvaluesum, df, honevent,attributename,attributevalue):
    
    if attributename != "na":
        honevent = str("trk_date_" + honevent + "_" + attributevalue)
    else:
        honevent = str("trk_date_" + honevent)
        
    hontargetvaluesum = int(hontargetvaluesum)

    if  all([honoperator == 'greater', honoperatorval == 'greater']):
        df=df[(df['count'] > hontargetvalue) & (df['metric'] > hontargetvaluesum)]
        functoupdate(df, honevent)
    elif all([honoperator == 'less', honoperatorval == 'less']):
        df=df[(df['count'] < hontargetvalue) & (df['metric'] < hontargetvaluesum)]
        functoupdate(df, honevent)
    elif all([honoperator == 'equal', honoperatorval == 'equal']):
        df=df[(df['count'] == hontargetvalue) & (df['metric'] == hontargetvaluesum)]
        functoupdate(df, honevent)

    elif all([honoperator == 'greater', honoperatorval == 'less']):
        df=df[(df['count'] > hontargetvalue) & (df['metric'] < hontargetvaluesum)]
        functoupdate(df, honevent)
    elif all([honoperator == 'greater', honoperatorval == 'equal']):
        df=df[(df['count'] > hontargetvalue) & (df['metric'] == hontargetvaluesum)]
        functoupdate(df, honevent)
    elif all([honoperator == 'greater', honoperatorval == 'na']):
        df=df[df['count'] > hontargetvalue]
        functoupdate(df, honevent)
    elif all([honoperator == 'equal', honoperatorval == 'na']):
        df=df[df['count'] == hontargetvalue]
        functoupdate(df, honevent)
    elif all([honoperator == 'less', honoperatorval == 'na']):
        df=df[df['count'] < hontargetvalue]
        functoupdate(df, honevent)

    elif all([honoperator == 'less', honoperatorval == 'greater']):
        df=df[(df['count'] < hontargetvalue) & (df['metric'] > hontargetvaluesum)]
        functoupdate(df, honevent)
    elif all([honoperator == 'equal', honoperatorval == 'greater']):
        df=df[(df['count'] == hontargetvalue) & (df['metric'] > hontargetvaluesum)]
        functoupdate(df, honevent)
    elif all([honoperator == 'na', honoperatorval == 'greater']):
        df=df[df['metric'] > hontargetvaluesum]
        functoupdate(df, honevent)
    elif all([honoperator == 'na', honoperatorval == 'equal']):
        df=df[df['metric'] == hontargetvaluesum]
        functoupdate(df, honevent)
    elif all([honoperator == 'na', honoperatorval == 'less']):
        df=df[df['metric'] < hontargetvaluesum]
        functoupdate(df, honevent)

    elif all([honoperator == 'na', honoperatorval == 'na']):
        print('You cannot have both operators NA in HoneyCode rules')