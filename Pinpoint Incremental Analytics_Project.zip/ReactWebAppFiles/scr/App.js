import React, { useState } from "react";
import './App.css';
import Amplify from 'aws-amplify';
import { withAuthenticator, AmplifySignOut } from '@aws-amplify/ui-react';
import {Analytics, AWSKinesisProvider } from 'aws-amplify';
import { Auth } from 'aws-amplify';
import awsconfig from './aws-exports';
import { Button, Navbar, Nav, NavDropdown,Row, Container, Col } from 'react-bootstrap'

Amplify.configure(awsconfig);
Analytics.configure(awsconfig);
Analytics.addPluggable(new AWSKinesisProvider());

var date = new Date();
var sestimestamp = new Date().getTime();

Analytics.configure({
    AWSKinesis: {
        region: 'us-east-1',
    } 
});


const usname = () => Auth.currentAuthenticatedUser({
    bypassCache: false  // Optional, By default is false. If set to true, this call will send a request to Cognito to get the latest user data
}).then(function(user){ 
    var sub = user.attributes.sub;
    var userm = user.attributes.email; 
    var sesid = user.signInUserSession.idToken.payload.aud;
    var sesstartt = user.signInUserSession.idToken.payload.auth_time;
    var sestimestampp = sestimestamp;
    var listofitems = {'userm':userm,'sesid':sesid,'sesstartt':sesstartt,'sestimestampp':sestimestampp, 'sub':sub};
    console.log(user);
    return listofitems})
.catch(err => console.log(err));

function App() {
    const [count, setCount] = useState(0);
    const [countr, setCountr] = useState(0);

    const pinanalyticsred = () => usname().then( 
      function(user){  
      Analytics.record( {name: 'redbutton' , 'Endpoint' : user.userm,
      attributes:{pagename:'homepage', Timestamp: date.toISOString(), ChannelType: 'EMAIL', Address: user.userm},
      metrics:{tasksadded: 1}}); 

      setCountr(prevCountr => prevCountr + 1);

      Analytics.updateEndpoint({
          address: user.userm, 
          ChannelType: 'EMAIL',
          userId: user.sub,
          optOut: 'NONE',
      });
      }).catch(err => console.log(err));
    
    const pinanalyticsgreen = () => usname().then(   
      function(user){  
      Analytics.record( {name: 'greenbutton' , 'Endpoint' : user.userm,
      attributes:{pagename:'homepage', Timestamp: date.toISOString(), ChannelType: 'EMAIL', Address: user.userm},
      metrics:{tasksadded: 1}}); 

      setCount(prevCount => prevCount + 1);

      Analytics.updateEndpoint({
          address: user.userm, 
          ChannelType: 'EMAIL',
          userId: user.sub,
          optOut: 'NONE',
      });
      }).catch(err => console.log(err));


    const resetg = (e) => {
      setCount(prevCount => 0);
    }

    const resetr = (e) => {
      setCountr(prevCountr => 0);
    }

    const redbutton = (e) => {  
      pinanalyticsred();
    };

    const greenbutton = (e) => {  
      pinanalyticsgreen();
    };
 
  return (
    <div className="App">

      <div>
        <Navbar bg="light" expand="lg">
          <Navbar.Brand><b>Pinpoint Incremental Analytics</b></Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
            </Nav>
            <AmplifySignOut />
          </Navbar.Collapse>
        </Navbar>
      </div>

      <div>
        <Container>
          <Row style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              margin: "30px",
              marginBottom: "60px",
              "color": "black",
              "font-size": "30px"
            }}>
            <Col md="auto"> <b>Click on a button to generate either Green or Red event </b></Col>
          </Row>
          <Row style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              margin: "10px"
            }}>
            <Col md="auto">
              <button onClick={resetg} className="reset">RESET</button>
            </Col>              
            <Col md="auto">
              <button onClick={greenbutton} className="greenbutton">GREEN + 1</button>
            </Col>
            <Col md="auto">
            <div className="counterresult">
                <p>{count}</p>
              </div>
            </Col>
          </Row>
          <Row style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              margin: "10px"
            }}>
            <Col md="auto">
              <button onClick={resetr} className="reset">RESET</button>
            </Col>
            <Col md="auto">
              <button onClick={redbutton} className="redbutton">RED + 1</button>
            </Col>
            <Col md="auto">
              <div className="counterresult">
                <p>{countr}</p>
              </div>
            </Col>
          </Row>
        </Container>
      </div>

    </div>
  );
};

export default withAuthenticator(App);


//Analytics.record({data: { name: 'taskadded' ,
//attributes:{pagename:'homepage'},
//metrics:{tasksadded: 1},
//Timestamp: date.toISOString(), userid: user.sub, ChannelType: 'EMAIL', Address: user.userm }, streamName: 'myappKinesis-dev'},
//'AWSKinesis'
//); 