from __future__ import print_function
import base64
import boto3
import json
import time
from datetime import datetime
from interaction_function import pushdata, querysumval, querycountval, incrementmetric, updateendpoint, getmetricvalue, honrules, dtconversion, pushdatahistory, resetcounter, put_trk_event, attributecrossreference
from businesslogic import businesslogic

print('Loading function')

def lambda_handler(event, context):
    output = []
    print(event)
    
    for record in event['Records']:
        
        payload = base64.b64decode(record['kinesis']['data'])
        payload2 = payload.decode('utf-8').replace("'", '"') #Decode using the utf-8 encoding

        # Do custom processing on the payload here
        payload2 = json.loads(payload) #load the json to a string
        print(payload2)

        #Defining the variables
        evname = str(payload2['event_type'])
        evnameold = str(payload2['event_type'])
        try:
            checkevent = attributecrossreference(payload2, evname)
            evname = str(checkevent[1])
            assessrulesflag = str(checkevent[2])
            delevname = str(checkevent[3])
        except:
            print("This event has no attribute")
            evname = evname
            delevname = str(evname) + str('na') + str('999')
            assessrulesflag ='donotassess'
            
        
        if all([evname[0:4] != "trk_", evname[0:1] != "_"]): #Filters out the trk events and all Pinpoint email, sms etc. events
            useridtsk = str(payload2['endpoint']['User']['UserId'] + evname)
            userid = str(payload2['endpoint']['User']['UserId'])
            eventdt=dtconversion(userid)
            endpointid = payload2['endpoint']['Id']
            appid = payload2['endpoint']['ApplicationId'] #PinpointApplicationID
            eventdtpro = str(datetime.fromtimestamp((payload2['event_timestamp'])/1000))[0:10]
            sesid = payload2['session']['session_id']
            starttimestamp = str(payload2['session']['start_timestamp'])
            timestamp = str(payload2['event_timestamp'])
            attributes = str(payload2['attributes'])

            print("This is a record for: " + evname)

            try:
                countval = querycountval(useridtsk) #Returns the count value of that event
            except:
                print('Event-User combination does not exist')
                try:
                    metric = getmetricvalue(payload2) #Returns the metric value of the first metric
                except:
                    metric = 0
                    if assessrulesflag !='donotassess': pushdata(useridtsk,metric,eventdtpro, delevname) #If this event doesn't exist in DynamoDB then this function creates it  
                    pushdatahistory(evnameold,userid,metric,eventdt,endpointid,attributes) #Push data to DynamoDB timeseries table
                else:
                    if assessrulesflag !='donotassess': pushdata(useridtsk,metric,eventdtpro, delevname) #If this event doesn't exist in DynamoDB then this function creates it  
                    pushdatahistory(evnameold,userid,metric,eventdt,endpointid,attributes) #Push data to DynamoDB timeseries table
            else:
                print('Event-User combination exists')
                try:
                    metric = getmetricvalue(payload2) #Returns the metric value of the first metric
                except:
                    metric = 0
                    incrementmetric(useridtsk,metric, eventdtpro) #processes the numerical change for the metric 
                    pushdatahistory(evnameold,userid,metric,eventdt,endpointid,attributes) #Push data to DynamoDB timeseries table
                else:
                    incrementmetric(useridtsk,metric, eventdtpro) #processes the numerical change for the metric 
                    pushdatahistory(evnameold,userid,metric,eventdt,endpointid,attributes) #Push data to DynamoDB timeseries table
                    countval = querycountval(useridtsk)
            
            try:
                #Call the function to obtain the rule from HoneyCode and then loops through to get the key variables
                honrows=honrules(evnameold, payload2)
                if honrows != "donotassess":
                    counter = 0 
                    for cell in honrows:
                        if counter == 4:
                            honoperator = cell['formattedValue']
                        elif counter == 5:
                            hontargetvalue = int(cell['formattedValue'])
                        elif counter == 8:
                            honreset = cell['formattedValue']
                        elif counter == 6:
                            honoperatorval = cell['formattedValue']
                        elif counter == 7:
                            hontargetvaluesum = cell['formattedValue']
                        counter = counter + 1
                else: 
                    print("Skipping HoneyCode rules assessment")

            except:
                print("No business rules for the event: " + evname)
            else:
                if honrows != "donotassess":
                    try:
                        countval = querycountval(useridtsk)
                    except:
                        print("No count for that event to assess the business rule")
                    else:
                        rulesmet=businesslogic(countval, honoperator, hontargetvalue, honoperatorval, hontargetvaluesum, useridtsk)
                        print(rulesmet)
                        if all([rulesmet == "ready", honreset == "yes"]):
                            put_trk_event(evname,sesid, endpointid)
                            resetcounter(useridtsk)
                        elif all([rulesmet == "not-ready", honreset == "yes"]):
                            print('Rules not met and hornset=yes')
                        elif all([rulesmet == "ready", honreset == "no"]):
                            campaignflag = 'ready'
                            updateendpoint(endpointid, appid, evname, campaignflag)
                        elif all([rulesmet == "not-ready", honreset == "no"]):
                            print('Rules not met and hornset=yes')
                        else:
                            print("User business criteria not met")
                else:
                    print("HoneyCode rules assessment skipped successfully")
    
                    
    print('Successfully processed all records')

    return {
        'statusCode': 200,
        'body': json.dumps('DONE')
    }
