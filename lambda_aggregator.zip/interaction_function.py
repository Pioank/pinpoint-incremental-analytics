import boto3
import json
from datetime import datetime
import os
honworkbookid = os.environ['WORKBOOK_ID']
hontableid = os.environ['TABLE_ID']
region = os.environ['AWS_REGION']
pinpointid = os.environ['PINPOINT_ID']
dynamodbendpointurl = "https://dynamodb." + region + ".amazonaws.com"

#Dynamo tables configuration and Boto3 client for Pinpoint and HoneyCode
dynamodb = boto3.resource('dynamodb', endpoint_url=dynamodbendpointurl)
table = dynamodb.Table('kinesis_pinpoint_aggregator')
tablehistory = dynamodb.Table('kinesis_pinpoint_timeseries')
clientpin = boto3.client('pinpoint')
clienthon = boto3.client('honeycode', region_name='us-west-2') #Don't change the region!!! HoneyCode is available only in US-WEST-2 as of 02-2021

# Adds the metric value under the same user    
def incrementmetric(useridtsk,metric, eventdt):
    # Update table item for metric
    table.update_item(
            Key={
                'useridtaskname': useridtsk,
            },
            UpdateExpression="set sumval = sumval + :val",
            ExpressionAttributeValues={
                ':val': metric
            },
            ReturnValues="UPDATED_NEW"   
        )
    # Update table item for the count of this event's occurances
    table.update_item(
            Key={
                'useridtaskname': useridtsk,
            },
            UpdateExpression="set countval = countval + :val",
            ExpressionAttributeValues={
                ':val': 1
            },
            ReturnValues="UPDATED_NEW"   
        )
    # Update lastdate with the event date
    table.update_item(
            Key={
                'useridtaskname': useridtsk,
            },
            UpdateExpression="set lastdate = :lastd",
            ExpressionAttributeValues={
                ':lastd': eventdt
            },
            ReturnValues="UPDATED_NEW"   
        )
    print('DynamoDB Aggregator Record has been updated for this user')

#Pushes data to DynamoDB aggregator table
def pushdata(useridtsk,metric, eventdt, evnameold):
    table.put_item(
       Item={
            'useridtaskname': useridtsk,
            'sumval': metric,
            'countval': 1,
            'firstdate':eventdt,
            'lastdate':eventdt,
            'eventname':evnameold
            }
    )
    print('New DynamoDB Aggregator Record')

#Retrieves the metric sum value of that event / user combination from DynamoDB 
def querysumval(useridtsk):
    queryresults = table.get_item(Key={'useridtaskname': useridtsk})
    sumvalresult = queryresults['Item']['sumval']
    return int(sumvalresult)

#Retrieves the count of that event / user combination from DynamoDB  
def querycountval(useridtsk):
    queryresults = table.get_item(Key={'useridtaskname': useridtsk})

    countvalresult = queryresults['Item']['countval']
    return int(countvalresult)

#Reseting the counter (counti) to 0 in DynamoDB based on the rule user set in HoneyCode
def resetcounter(useridtsk):
    table.update_item(
        Key={
            'useridtaskname': useridtsk
        },
        UpdateExpression="set sumval=:r",
        ExpressionAttributeValues={
            ':r': 0
        },
        ReturnValues="UPDATED_NEW"
    )
    table.update_item(
        Key={
            'useridtaskname': useridtsk
        },
        UpdateExpression="set countval=:r",
        ExpressionAttributeValues={
            ':r': 0
            
        },
        ReturnValues="UPDATED_NEW"
    )
    print('DynamoDB Aggregator record has been RESET')
    
#Pushes data to DynamoDB table that stores timeseries
def pushdatahistory(evname,userid,metric,eventdt,endpointid,attributes):
    tablehistory.put_item(
       Item={
            'eventname': evname,
            'dateuserid': eventdt,
            'metric': metric,
            'endpointid': endpointid,
            'count' : 1,
            'attributes':attributes
            }
    )
    print('DynamoDB Timeseries Record has been pused: ' + eventdt)


#Gets the metric value
def getmetricvalue(payload2):
    metric = payload2['metrics']
    for key, value in metric.items():
        metric=int(value)
        break
    return metric

#Updates endpoint attribute when rules are met
def updateendpoint(endpointid, appid, evname, campaignflag):
    clientpin.update_endpoint(
    ApplicationId=appid,
    EndpointId= endpointid,
    EndpointRequest={'User':{'UserAttributes': {
            evname: [campaignflag]}
            }}
            
    )
    print('Pinpoint User Attribute has been updated:' + evname + " " + campaignflag)

#Converts timestamp to date & time separated by # converted to str - timestamp is generated at the processing not from the event payload so it can be unique  
def dtconversion (userid):
    result=str(datetime.now())
    replval = str('#'+str(userid)+'#')
    result=str(result).replace(" ", replval)
    return result

# Puts event to Pinpoint for aggregators that reset
def put_trk_event(evname,sesid, endpointid):
    flagevent = str("trk_" + evname)
    ts = str(datetime.now().isoformat())

    print(clientpin.put_events(
        ApplicationId=pinpointid,
        EventsRequest={
            'BatchItem': {
                endpointid: {
                    'Endpoint': {
                        'ChannelType': 'EMAIL',
                        'OptOut': 'NONE'
                        },
                    'Events': {
                        sesid: {
                            'EventType': flagevent,
                            'Session': {
                                'Id': sesid, 
                                'StartTimestamp': ts,
                            },
                            'Timestamp': ts
                        }
                    }
                }
            }
        }
    ))
        
    print("trk event sent for: " + flagevent)

#Get rules from Honeycode
def honrules(evname, payload2):

    #Cross references attributes from Payload with Attributes from the Event Payload
    honrows=attributecrossreference(payload2, evname)

    assessflagcheck = str(honrows[2])
    if assessflagcheck == "assess":
        honrows=str(honrows[0]).replace("'", '"')
        honrows = json.loads(honrows)
        honrows = honrows['cells']
        print("HoneyCode rules have been obtained")
    elif assessflagcheck == "donotassess":
        honrows = "donotassess"
        print("Rules should not be assessed as event attributes do not match aggregator rule attributes")
    
    return honrows
    
#Cross references attributes from Payload with Attributes from the Event Payload
def attributecrossreference(payload2, evname):
    newevname = evname
    
    honkey = str('aggregator'+ evname)
    honrows = clienthon.query_table_rows(workbookId=honworkbookid,tableId=hontableid,filterFormula={"formula": f'=Filter(rules,"rules[Key]=%","{honkey}")'},maxResults=99)
        
    honrows=str(honrows).replace("'", '"')
    honrows=json.loads(honrows)
    honrows=honrows['rows']
    rownumb = 0

    safecount = 0 #In case there are 2 rules with the same EventName,AttributeName and AttributeValue this safecount wouldn't allow the script to process the data more than once

    for row in honrows:
        honrowprocess=str(row).replace("'", '"')
        honrowprocess = json.loads(honrowprocess)
        honrowprocess = honrowprocess['cells']
        rownumb = rownumb + 1
        
        counter = 0
        for cell in honrowprocess:
            if counter == 2:
                attributename = str(cell['formattedValue'])
            elif counter == 3:
                attributevalue = str(cell['formattedValue'])
            counter = counter + 1
         
        try:
            evattributes = payload2['attributes']
        except:
            print("The event " + evname + " does not have attributes in the event Payload")
        else:
            for k, v in evattributes.items():
                if all([k == attributename, v == attributevalue]):
                    print("The event " + evname + " has attributes on both HoneyCode and event Payload")
                    print("Attribute name: " + k)
                    print("Attribute value: " + v)
                    selectedrow = row
                    if safecount == 0:
                        newevname = str(evname) + "_" + str(v)
                        safecount = safecount + 1
                        delevname = str(evname) + str(k) + str(v) 
                    else:
                        print("More than 1 rule with the same EventName, AttributeName and AttributeValue")
        
    # Creates an "assessrulesflag" and depending the match or existance of attributes between HoneyCode rules and event Payload, it passess back either assess or donotassess flag
    if all([newevname != evname, attributename != "na"]):
        print("The new event name is " + newevname)
        evname = newevname
        assessrulesflag = "assess"
    elif attributename == "na":
        assessrulesflag = "assess"
        delevname = str(evname) + str('na') + str('999')
    else: 
        print("HoneyCode rule attribute value doesn't match the Payload event attributes")
        assessrulesflag = "donotassess"
    print("Rule assess flag: " + assessrulesflag)
    row = str(row)     
    result = [row,evname,assessrulesflag,delevname]
    
    
    return result