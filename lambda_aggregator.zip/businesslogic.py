from interaction_function import querysumval


def businesslogic(countval, honoperator, hontargetvalue, honoperatorval, hontargetvaluesum, useridtsk):
    
    print("Assessing the business rules from HoneyCode")

    sumval = int(querysumval(useridtsk))
    hontargetvaluesum =int(hontargetvaluesum)

    def countevent(honoperator,hontargetvalue,countval):  
        if honoperator == 'greater':
            if countval > hontargetvalue:
                campaignflaga = 'ready'
            else:
                campaignflaga = 'not-ready'
        elif honoperator == 'smaller':
            if countval < hontargetvalue:
                campaignflaga = 'ready'
            else:
                campaignflaga = 'not-ready'
        elif honoperator == 'equal':
            if countval == hontargetvalue:
                campaignflaga = 'ready'
            else:
                campaignflaga = 'not-ready'
        else:
            campaignflaga = 'ready'
        
        print("This is the Dynamo countval, operator, rule sum: " + str(countval) + " " + honoperator + " " + str(hontargetvalue) + " " + campaignflaga)
                
        return campaignflaga

    def sumvalue(honoperatorval, hontargetvaluesum, sumval):  
        if honoperatorval == 'greater':
            if sumval > hontargetvaluesum:
                campaignflagc = 'ready'
            else:
                campaignflagc = 'not-ready'
        elif honoperatorval == 'smaller':
            if sumval < hontargetvaluesum:
                campaignflagc = 'ready'
            else:
                campaignflagc = 'not-ready'
        elif honoperatorval == 'equal':
            if sumval == hontargetvaluesum:
                campaignflagc = 'ready'
            else:
                campaignflagc = 'not-ready'
        else:
            campaignflagc = 'ready'
            
        print("This is the Dynamo sumval, operator, rule count: " + str(sumval) + " " + honoperatorval + " " + str(hontargetvaluesum) + " " + campaignflagc)
    
        return campaignflagc
    
    countflag = countevent(honoperator,hontargetvalue,countval)
    sumflag = sumvalue(honoperatorval, hontargetvaluesum, sumval)
    
    if all([honoperator != "na", honoperatorval != "na"]):
        print("Assessing both values and count")
        if all([countflag == "ready", sumflag=="ready"]):
            campaignflag='ready'
        else:
            campaignflag='not-ready'
    elif all([honoperator != "na", honoperatorval == "na"]) :
        if countflag == 'ready':
            campaignflag='ready'
        else:
            campaignflag='not-ready'        
    elif all([honoperator == "na", honoperatorval != "na"]):
        if sumflag == 'ready':
            campaignflag='ready'
        else:
            campaignflag='not-ready'      
    
    print("All business rules have now been evaluated and the result is:" + campaignflag)
    return campaignflag
        
